import socket
import time
from _thread import *

import pygame

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("192.168.1.218", 5555))


def fa_string_pa_blocknum(blocketsnummer):
    if blocketsnummer == -1:
        return "luft"
    else:
        return block[blocketsnummer]


def fa_lista_fran_mail(mail):
    sidan = mail.split(", ")
    numh = 0
    for vi in sidan:
        vari = fa_string_pa_blocknum(int(vi))
        sidan[numh] = vari
        numh += 1
    return sidan


def server(none):
    global sida, skicka
    if none:
        pass
    while True:
        meddelande = s.recv(2048).decode()
        print(meddelande)
        if meddelande != "inget":
            sida = fa_lista_fran_mail(meddelande)
        s.send(str.encode(skicka))
        skicka = "ok"


skicka = "ok"
vidd, hoejd = 1000, 600
gameDisplay = pygame.display.set_mode((vidd, hoejd))
person = pygame.image.load(".bilder/Person.png")

jord = pygame.image.load(".bilder/Jord.png")
sand = pygame.image.load(".bilder/Sand.png")
sten = pygame.image.load(".bilder/Sten.png")
trae = pygame.image.load(".bilder/Trae.png")

kryss = pygame.image.load(".bilder/Kryss.png")

x, y = 0, 250
hall = "h"
block = ["trae", "sten", "jord", "sand"]
blocknum = []
for v in block:
    blocknum.append(1)

hopp, hoppnum = False, 0
olika_hall = ["h", "v", "u", "n"]
hallplus = [(75, 25), (-25, 25), (25, -25), (25, 75)]
kx, ky = 0, 0
bakgrundsfarg = (0, 0, 200)
sida = []
halleri = block[0]

start_new_thread(server, (None,))


def fa_pos(nummer):
    xh = (nummer % 20) * 50
    yh = int(nummer / 20) * 50
    return xh, yh


def fa_num_pa_block(blockstring):
    try:
        return block.index(blockstring)
    except ValueError:
        return -1


def rita_allt():
    global kx, ky
    gameDisplay.fill(bakgrundsfarg)
    numh = 0
    for vi in sida:
        if vi != "luft":
            gameDisplay.blit(globals()[vi], fa_pos(numh))
        numh += 1
    gameDisplay.blit(person, (x, y))
    kx, ky = x, y
    hallplusning = hallplus[olika_hall.index(hall)]
    kx += hallplusning[0]
    ky += hallplusning[1]
    bild = pygame.transform.scale(globals()[halleri], (20, 20))
    if blocknum[block.index(halleri)] > 0:
        gameDisplay.blit(bild, (kx, ky))
    gameDisplay.blit(kryss, (kx, ky))


def player_actions():
    global x, y, hall, hopp, hoppnum, sida, skicka
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        try:
            if gameDisplay.get_at((x - 3, y + 5)) == bakgrundsfarg:
                x -= 3
        except IndexError:
            if x - 4 < 0:
                x -= 3
        hall = "v"

    if keys[pygame.K_RIGHT]:
        try:
            if gameDisplay.get_at((x + 53, y + 5)) == bakgrundsfarg:
                x += 3
        except IndexError:
            if x + 54 > 1000:
                x += 3
        hall = "h"
    if keys[pygame.K_UP]:
        hall = "u"
    if keys[pygame.K_DOWN]:
        hall = "n"

    if keys[pygame.K_SPACE]:
        if not hopp and gameDisplay.get_at((x + 25, y + 53)) != bakgrundsfarg:
            hopp = True
            hoppnum = 0

    if hopp:
        try:
            if gameDisplay.get_at((x + 25, y - 3)) == bakgrundsfarg:
                y -= 3
            else:
                hopp = False
        except IndexError:
            if y - 5 < 0:
                y -= 3
        hoppnum += 1
        if hoppnum > 30:
            hopp = False
    try:
        if gameDisplay.get_at((x + 25, y + 50)) == bakgrundsfarg and not hopp and -25 < x and x + 50 < 1025:
            y += 6
    except IndexError:
        if y + 55 > hoejd:
            y += 6
    try:
        bx = int(kx / 50)
        by = int(ky / 50)
        pblock = by * 20 + bx
        btyp = sida[pblock]

        if keys[pygame.K_x]:
            if btyp != "luft":
                skicka = "högg " + str(pblock)
        if keys[pygame.K_v]:
            if btyp == "luft":
                skicka = "satte " + str(pblock) + " " + halleri
    except IndexError:
        pass


def main():
    global x, y, sida, skicka, halleri
    clock = pygame.time.Clock()
    vanta = False
    while True:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                key = pygame.key.get_pressed()
                if key[pygame.K_n]:
                    numh = block.index(halleri) + 1
                    langd = len(block) - 1
                    if numh == langd + 1:
                        numh = 0
                    count = 0
                    while True:
                        if blocknum[numh] != 0:
                            halleri = block[numh]
                            break

                        numh += 1
                        count += 1
                        if numh > langd:
                            numh = 0
                        if count > langd:
                            break
        rita_allt()
        player_actions()
        pygame.display.update()
        if x > 1000:
            skicka = "ut x 1"
            x = 0
        if x < -50:
            skicka = "ut x -1"
            x = 950
        if y > 600:
            skicka = "ut y 1"
            y = 0
        if y < -50:
            skicka = "ut y -1"
            y = 525
        if skicka.__contains__("ut "):
            vanta = True
        while skicka.__contains__("ut "):
            pass
        if vanta:
            time.sleep(0.3)
            vanta = False


main()
