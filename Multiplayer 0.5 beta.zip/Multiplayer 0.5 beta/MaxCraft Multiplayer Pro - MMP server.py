import os
import random
import socket
from _thread import *

import time

varld = input("Vilken värld vill du hosta? ")

try:
    os.mkdir(".varldar/" + varld)
except FileExistsError:
    pass

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s.bind(("", 5555))

s.listen()

print("Servern startad...")

block = ["trae", "sten", "jord", "sand"]

sidor = []


def fa_num_pa_block(blockstring):
    try:
        return block.index(blockstring)
    except ValueError:
        return -1


def fa_string_pa_blocknum(blocknum):
    if blocknum == -1:
        return "luft"
    else:
        return block[blocknum]


def fa_string(lista):
    return str(lista).replace("[", "").replace("]", "").replace("'", "").replace("(", "").replace(")", "")


def lika_med(lista):
    tillbaks = []
    for v in lista:
        tillbaks.append(v)
    return tillbaks


def paper_handler(sida, usida):
    try:
        globals()["sidan" + str(sida) + "u" + str(usida)]
    except KeyError:
        try:
            fil = open(".varldar/" + varld + "/sidan" + str(sida) + "u" + str(usida), "r")
            globals()["sidan" + str(sida) + "u" + str(usida)] = fil.read().split(", ")
            fil.close()
            sidor.append("sidan" + str(sida) + "u" + str(usida))
        except FileNotFoundError:
            globals()["sidan" + str(sida) + "u" + str(usida)] = []
            sidor.append("sidan" + str(sida) + "u" + str(usida))
            for numh in range(0, 240):
                globals()["sidan" + str(sida) + "u" + str(usida)].append(random.choice(block))
    return globals()["sidan" + str(sida) + "u" + str(usida)]


def client(conn):
    try:
        forut = 982121
        sida, usida = 0, 0
        sidan = paper_handler(sida, usida)
        while True:
            if sidan != forut:
                li = []
                for numh in range(0, 240):
                    li.append(fa_num_pa_block(sidan[numh]))
                conn.send(str.encode(fa_string(li)))
            else:
                conn.send(str.encode("inget"))

            forut = lika_med(sidan)

            meddelande = conn.recv(2048).decode()
            if meddelande.__contains__("högg "):
                sidan[int(meddelande.split(" ")[1])] = "luft"
            if meddelande.__contains__("satte "):
                sidan[int(meddelande.split(" ")[1])] = meddelande.split(" ")[2]
                print(sidan)
            if meddelande.__contains__("ut "):
                xey = meddelande.split(" ")[1]
                if xey == "x":
                    sida += int(meddelande.split(" ")[2])
                else:
                    usida += int(meddelande.split(" ")[2])
                sidan = paper_handler(sida, usida)

            time.sleep(0.2)
    except Exception as e:
        print("En client har stött på ett problem. Här är errorn:")
        print(e)
        print("Clienten tvingades avanslutas från servern. Vi beklagar.")


def acceptera_nya_clienter(none):
    if none:
        pass
    while True:
        connection, address = s.accept()
        start_new_thread(client, (connection,))
        print(str(address) + " har anslutit.")


start_new_thread(acceptera_nya_clienter, (None,))


def spara():
    for v in sidor:
        lista = globals()[v]
        fil = open(".varldar/" + varld + "/" + v, "w")
        fil.write(fa_string(lista))
        fil.close()


while True:
    command = input("Du kan när som helst skriva kommandon till servern.")
    if command.lower() == "exit":
        spara()
        break
    if command.lower() == "spara":
        spara()
    if command.lower().__contains__("kick"):
        print("Det går tyvärr inte att kicka folk ur världen ännu.")
