import pygame
import random
import os
import time

# skapa mappen där världar sparas
try:
    os.mkdir(".worlds")
except os.error:
    "finns redan"
# skapa mappen där inställningar sparas
try:
    os.mkdir(".inställningar")
except os.error:
    "finns redan"
# skapa mappen där inställningen fredlig sparas
try:
    b = open(".inställningar/" + "/fredlig", "x")
    b.close()
except FileExistsError:
    "finns redan"
frefrao = open(".inställningar/" + "/fredlig", "r")
frefra = frefrao.read()
frefra = frefra.strip()
frefrao.close()
if frefra == "":
    h = open(".inställningar/" + "/fredlig", "w")
    h.write("False")
    h.close()

pygame.init()

vidd, hoejd = 1000, 600

pygame.display.set_caption("MaxCraft")
pygame.display.set_icon(pygame.image.load(".images/diamond.png"))

mus = pygame.transform.scale((pygame.image.load(".images/.Mus.png")), (20, 20))
mus_gron = pygame.transform.scale((pygame.image.load(".images/.Mus_grön.png")), (20, 20))
pekmus = pygame.image.load(".images/Pekmus.png")
pekmus_bla = pygame.image.load(".images/Pekmus_blå.png")

bak = pygame.image.load(".images/Bak.png")

jord = pygame.transform.scale((pygame.image.load(".images/gameDirtBlock.png")), (50, 50))
trae = pygame.transform.scale((pygame.image.load(".images/gameWoodBlock.png")), (50, 50))
sand = pygame.transform.scale((pygame.image.load(".images/gameSandBlock.png")), (50, 50))
graes = pygame.transform.scale((pygame.image.load(".images/gameGrassBlock.png")), (50, 50))
loev = pygame.transform.scale((pygame.image.load(".images/gameLeafBlock.png")), (50, 50))
sten = pygame.transform.scale((pygame.image.load(".images/gameStoneBlock.png")), (50, 50))
diamant = pygame.transform.scale((pygame.image.load(".images/diamond.png")), (50, 50))
smaragd = pygame.transform.scale((pygame.image.load(".images/Smaragd.png")), (50, 50))
koblock = pygame.transform.scale((pygame.image.load(".images/Cowblock.png")), (50, 50))
zombieblock = pygame.transform.scale((pygame.image.load(".images/Zomblock.png")), (50, 50))
havsblock = pygame.transform.scale((pygame.image.load(".images/Hav.png")), (50, 50))
kaktus = pygame.transform.scale((pygame.image.load(".images/Kaktus.png")), (50, 50))
granit = pygame.transform.scale((pygame.image.load(".images/Granit.png")), (50, 50))
kista = pygame.transform.scale((pygame.image.load(".images/Kista.png")), (50, 50))
ko = pygame.transform.scale((pygame.image.load(".images/Cow.png")), (100, 75))
zombie = pygame.transform.scale((pygame.image.load(".images/Zombie.png")), (75, 100))
person = pygame.transform.scale((pygame.image.load(".images/Person.png")), (50, 50))
kryss = pygame.transform.scale((pygame.image.load(".images/Kryss.png")), (5, 5))
tegel = pygame.transform.scale((pygame.image.load(".images/Tegel.png")), (50, 50))

doe = pygame.image.load(".images/Dö.png")

gameDisplay = pygame.display.set_mode((vidd, hoejd))


def skriv(text, tx=400, ty=300, storlek=75, farg=(0, 0, 0)):
    font = pygame.font.SysFont(None, storlek)
    txt = font.render(text, True, farg)
    gameDisplay.blit(txt, (tx, ty))


def skriva_i_pygame(fraga):
    namn3 = ""
    while True:

        gameDisplay.fill((0, 245, 100))

        skriv(fraga, 0, 100)

        event = pygame.event.poll()

        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

        if event.type == pygame.KEYDOWN:
            keys = pygame.key.get_pressed()
            key = pygame.key.name(event.key)  # Returns string id of pressed key.

            if len(key) == 1:  # This covers all letters and numbers not on numpad.
                if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]:

                    namn3 += key.upper()
                else:
                    namn3 += key

            elif key == "backspace":
                namn3 = namn3[:len(namn3) - 1]
            elif key == "space":
                namn3 += " "
            elif event.key == pygame.K_RETURN:
                return namn3

        skriv(namn3, 0, 300, 50)
        pygame.display.update()


def hemskarm():
    gameDisplay.fill((100, 100, 255))
    pek = False
    hem = True
    name = ""
    pygame.mouse.set_visible(False)
    while hem:
        gameDisplay.fill((100, 100, 255))

        muspos = pygame.mouse.get_pos()

        musx, musy = muspos

        for event3 in pygame.event.get():
            if event3.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event3.type == pygame.MOUSEBUTTONDOWN:
                if 550 > musx > 400 and 200 < musy < 235:
                    name = skriva_i_pygame("Vad ska den heta? ")
                    hem = False
                elif 520 > musx > 400 and 300 < musy < 335:
                    name = oppna()
                    hem = False
                elif 600 > musx > 400 and 400 < musy < 435:
                    installningar()

        skriv("MaxCraft", 350, 50, 100, (155, 0, 50))
        skriv("Ny värld", 400, 200, 50)
        skriv("Öppna", 400, 300, 50)
        skriv("Inställningar", 400, 400, 50)

        if not pek:
            gameDisplay.blit(mus, muspos)

        if 520 > musx > 400 and 300 < musy < 335 or 550 > musx > 400 and \
                200 < musy < 235 or 600 > musx > 400 and 400 < musy < 435:
            gameDisplay.blit(pekmus_bla, (musx, musy))
            pek = True

        else:
            pek = False

        pygame.display.update()

    pygame.mouse.set_visible(True)
    return name


def installningar():
    frefrao2 = open(".inställningar/" + "/fredlig", "r")
    frefra2 = frefrao2.read()
    frefra2 = frefra2.strip()
    frefrao2.close()
    pek = False
    ins = True
    while ins:
        muspos = pygame.mouse.get_pos()
        musx, musy = muspos

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if 600 > musx > 400 and 200 < musy < 235:
                    if frefra2 == "False":
                        frefra2 = "True"
                        o = open(".inställningar/" + "/fredlig", "w")
                        o.write("True")
                        o.close()
                    elif frefra2 == "True":
                        frefra2 = "False"
                        o = open(".inställningar/" + "/fredlig", "w")
                        o.write("False")
                        o.close()
                if 50 > musx > 0 and 0 < musy < 50:
                    ins = False

        gameDisplay.fill((20, 255, 255))
        skriv("Fredlig: " + frefra2, 400, 200, 50)

        gameDisplay.blit(bak, (0, 0))

        if not pek:
            gameDisplay.blit(mus, muspos)

        if 600 > musx > 400 and 200 < musy < 235 \
                or 50 > musx > 0 and 0 < musy < 50:
            gameDisplay.blit(pekmus_bla, (musx, musy))
            pek = True

        else:
            pek = False

        pygame.display.update()


# namnet på världen
def oppna():
    nx = 0
    ny = 0
    num = 0
    gameDisplay.fill((255, 255, 255))
    while True:
        try:
            skriv(os.listdir(".worlds/")[num], nx, ny, 25)
            globals()["varld" + str(num)] = os.listdir(".worlds/")[num]
        except IndexError:
            pygame.display.update()
            pygame.image.save(gameDisplay, ".bakgrund.png")
            break
        nx += 100
        num += 1
        if nx > 900:
            ny += 30
            nx = 0
    bakgrund = pygame.image.load(".bakgrund.png")
    os.remove(".bakgrund.png")
    lx = 0
    ly = 30
    num2 = 0
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                keyz = pygame.key.get_pressed()
                if keyz[pygame.K_RIGHT]:
                    if lx + 100 < 1000:
                        lx += 100
                    else:
                        lx = 0
                        ly += 30
                    num2 += 1
                if keyz[pygame.K_LEFT]:
                    if lx - 100 >= 0:
                        lx -= 100
                    else:
                        if ly - 30 > 0:
                            lx = 900
                            ly -= 30
                    num2 -= 1
                if keyz[pygame.K_DOWN]:
                    ly += 30
                    num2 += 10
                if keyz[pygame.K_UP]:
                    ly -= 30
                    num2 -= 10

                if keyz[pygame.K_RETURN]:
                    try:
                        print(globals()["varld" + str(num2)])
                        return globals()["varld" + str(num2)]
                    except KeyError:
                        gameDisplay.fill((0, 0, 255))
                        skriv("Du har inte en värld markerad.", 50)
                        pygame.display.update()
                        time.sleep(1)

        gameDisplay.blit(bakgrund, (0, 0))

        pygame.draw.line(gameDisplay, (255, 0, 0), (lx, ly), (lx + 20, ly), 5)

        pygame.display.update()


namn = hemskarm()

try:
    os.mkdir(".worlds/" + namn)
except os.error:
    "finns redan"


def avrunda(z, base=50):
    return base * round(z / base)


# inte bara generator utan också öppnare av redan genererade papper
# sid är pappret man är på
def generator(sid, underjord=""):
    done = False

    generatornum = 0

    # finns pappret? annars skapas det
    try:
        op = open(".worlds/" + namn + "/sida" + str(sid) + underjord, "x")
        op.close()

    # om det finns så läses det
    except FileExistsError:
        opr = open(".worlds/" + namn + "/sida" + str(sid) + underjord, "r")
        yu = opr.read()
        done = True
        tja = True
        num = 0
        while tja:
            globals()["ruta" + str(num)] = yu.split("/")[num]
            num += 1
            if num > 255:
                tja = False
        opr.close()

    op = ""

    # inte skriva om den redan läst att pappret finns
    if not done:
        op = open(".worlds/" + namn + "/sida" + str(sid) + underjord, "w")
        trnum = 0
        # alla rutor ska vara "" för att man ska kunna generera strukturer
        while True:
            globals()["ruta" + str(trnum)] = ""
            trnum += 1
            if trnum > 257:
                break

    if underjord == "":
        biom = random.randint(1, 5)
        # om det blir fem är det sen en av fem att det verkligen blir ett tempel
        tempelcheck = True
        while biom == 5 and tempelcheck:
            sakert = random.randint(1, 5)
            if sakert == 1:
                biom = 5
                tempelcheck = False
            else:
                biom = random.randint(1, 5)



    else:
        biom = 0

    # själva generatorn
    while not done:
        # underjord
        if biom == 0:
            hej = random.randint(1, 2)
            if hej == 1:
                skum = random.randint(1, 250)
                if skum == 1:
                    globals()["ruta" + str(generatornum)] = "diamant"
                elif skum == 2:
                    globals()["ruta" + str(generatornum)] = "smaragd"
                else:
                    stentyp = random.randint(1, 7)
                    if stentyp == 1:
                        globals()["ruta" + str(generatornum)] = "granit"
                    else:
                        globals()["ruta" + str(generatornum)] = "sten"
            else:
                globals()["ruta" + str(generatornum)] = "sten"

        # skogbiom
        elif biom == 1:
            # vad ska finnas på rutan?
            hej = random.randint(1, 4)
            # för att det ska kunna slumpas fram träd och andra strukturer måste den checka att det inte redan
            # bestämts vad rutan är
            if globals()["ruta" + str(generatornum)] == "":
                # jord ska inte vara uppe i himlen
                if generatornum > 200:
                    if hej == 1:
                        globals()["ruta" + str(generatornum)] = "sand"
                    elif hej == 2:
                        globals()["ruta" + str(generatornum)] = "jord"

                    # det uppstår luft lite här och var
                    else:
                        globals()["ruta" + str(generatornum)] = "air"
                # jord ska inte vara i himlen, men trädens toppar får vara där
                else:
                    if hej == 3 and globals()["ruta" + str(generatornum + 1)] == "" and globals()["ruta" + str(
                            generatornum + 2)] == "":
                        if 100 < generatornum < 180:
                            globals()["ruta" + str(generatornum)] = "loev"
                            globals()["ruta" + str(generatornum + 1)] = "loev"
                            globals()["ruta" + str(generatornum + 2)] = "loev"
                            globals()["ruta" + str(generatornum + 21)] = "trae"
                            globals()["ruta" + str(generatornum + 41)] = "trae"
                            globals()["ruta" + str(generatornum + 51)] = "trae"
                            globals()["ruta" + str(generatornum + 61)] = "trae"
                    else:
                        globals()["ruta" + str(generatornum)] = "air"

            # om rutan är förbestämd behövs det inte göras någonting
            else:
                ""
            if globals()["ruta" + str(generatornum)] == "":
                globals()["ruta" + str(generatornum)] = "air"

            # långt ner ska det vara jord eller sand, inte luft
            if generatornum > 199 and globals()["ruta" + str(generatornum)] == "air":
                sajo = random.randint(1, 2)
                if sajo == 1:
                    globals()["ruta" + str(generatornum)] = "sand"
                elif sajo == 2:
                    globals()["ruta" + str(generatornum)] = "jord"

        # bergbiom
        elif biom == 2:
            hej = random.randint(1, 3)
            dia = random.randint(1, 500)
            if hej == 1:
                globals()["ruta" + str(generatornum)] = "sten"

            else:
                globals()["ruta" + str(generatornum)] = "air"
            # för att det ska bli höga berg och inte bara random stenblock
            try:
                if globals()["ruta" + str(generatornum - 20)] == "sten":
                    globals()["ruta" + str(generatornum)] = "sten"
            except KeyError:
                "-20 finns inte"

            if dia == 1:
                globals()["ruta" + str(generatornum)] = "diamant"
            elif dia == 2:
                globals()["ruta" + str(generatornum)] = "smaragd"

            if globals()["ruta" + str(generatornum)] == "":
                globals()["ruta" + str(generatornum)] = "sten"

        # fältbiom
        elif biom == 3:
            hej = random.randint(1, 2)
            if generatornum < 180:
                globals()["ruta" + str(generatornum)] = "air"
            elif 160 < generatornum < 200:
                hej2 = random.randint(1, 3)
                if hej2 == 1:
                    globals()["ruta" + str(generatornum)] = "sand"
                elif hej2 == 2:
                    globals()["ruta" + str(generatornum)] = "jord"
                elif hej2 == 3:
                    globals()["ruta" + str(generatornum)] = "graes"
            else:
                if hej == 1:
                    globals()["ruta" + str(generatornum)] = "sand"
                elif hej == 2:
                    globals()["ruta" + str(generatornum)] = "jord"

        # ökenbiom
        elif biom == 4:
            # högt upp är det luft
            if generatornum < 160:
                globals()["ruta" + str(generatornum)] = "air"

            # en bit över sandytan ska katusars toppar kunna finnas
            if 160 > generatornum > 140:
                hej = random.randint(1, 5)
                if hej == 1:
                    globals()["ruta" + str(generatornum)] = "kaktus"
                else:
                    globals()["ruta" + str(generatornum)] = "air"
                # detta är för att det inte ska bli kaktusar bredvid varandra
                if globals()["ruta" + str(generatornum - 1)] == "kaktus":
                    globals()["ruta" + str(generatornum)] = "air"
            # lite längre ner bildas det allt oftare kaktusar, så det finns färre som är tre block höga än som är 1-2
            elif 200 > generatornum > 160:
                hej = random.randint(1, 2)
                if hej == 1:
                    globals()["ruta" + str(generatornum)] = "kaktus"
                elif hej == 2:
                    globals()["ruta" + str(generatornum)] = "air"
                # detta är för att det inte ska bli kaktusar bredvid varandra
                if globals()["ruta" + str(generatornum - 1)] == "kaktus":
                    globals()["ruta" + str(generatornum)] = "air"

                if globals()["ruta" + str(generatornum - 20)] == "kaktus":
                    globals()["ruta" + str(generatornum)] = "kaktus"

            elif generatornum > 199:
                globals()["ruta" + str(generatornum)] = "sand"

        # kistbiom
        elif biom == 5:
            hej = random.randint(1, 2)
            if hej == 1:
                u = random.randint(1, 50)
                if u == 1:
                    globals()["ruta" + str(generatornum)] = "kista"
                else:
                    globals()["ruta" + str(generatornum)] = "tegel"
            elif hej == 2:
                globals()["ruta" + str(generatornum)] = "tegel"
            if generatornum < 180:
                globals()["ruta" + str(generatornum)] = "air"
                zo = random.randint(1, 20)
                if zo == 1 or zo == 2:
                    globals()["ruta" + str(generatornum)] = "tegel"
                elif zo == 3:
                    globals()["ruta" + str(generatornum)] = "zombieblock"
            if generatornum < 20:
                globals()["ruta" + str(generatornum)] = "tegel"
                if random.randint(1, 10) == 1:
                    globals()["ruta" + str(generatornum)] = "air"

        op.write(globals()["ruta" + str(generatornum)] + "/")

        generatornum += 1

        if generatornum > 255:
            done = True
            op.close()


def doe_funktion():
    while True:
        for event2 in pygame.event.get():
            if event2.type == pygame.QUIT:
                avsluta()
        gameDisplay.blit(doe, (0, 0))
        keyc = pygame.key.get_pressed()
        if keyc[pygame.K_s]:
            avsluta(end=False)
        pygame.display.update()


# gör allt som behövs för att göra en manuell avslutning
def avsluta(sanum=0, jonum=0, lonum=0, trnum=0, stnum=0, dinum=0, smnum=0, grnum=0, kanum=0, granitnum=0, konum=0,
            kinum=0, tenum=0, zonum=0, natt=False, nattnum=0, hunger=10, end=True, sida=0):
    # dia!
    try:
        h2 = open(".worlds/" + namn + "/block", "x")
        h2.close()
    except FileExistsError:
        "behövs inte skapas, finns redan"
    oskr = open(".worlds/" + namn + "/block", "w")
    oskr.write(str(sanum) + "/" + str(jonum) + "/" + str(lonum) + "/" + str(trnum) + "/" + str(stnum) + "/" + str(dinum)
               + "/" + str(smnum) + "/" + str(grnum) + "/" + str(kanum) + "/" + str(granitnum) + "/" + str(konum)
               + "/" + str(kinum) + "/" + str(tenum) + "/" + str(zonum))
    # dia!
    oskr.close()
    # skriv ner om det är natt eller inte
    try:
        h2 = open(".worlds/" + namn + "/natt", "x")
        h2.close()
    except FileExistsError:
        "behövs inte skapas, finns redan"
    s = open(".worlds/" + namn + "/natt", "w")
    s.write(str(natt) + "/" + str(nattnum))
    s.close()

    try:
        h2 = open(".worlds/" + namn + "/hunger", "x")
        h2.close()
    except FileExistsError:
        "behövs inte skapas, finns redan"
    s = open(".worlds/" + namn + "/hunger", "w")
    s.write(str(hunger))
    s.close()

    try:
        h2 = open(".worlds/" + namn + "/sidan", "x")
        h2.close()
    except FileExistsError:
        "behövs inte skapas, finns redan"
    s = open(".worlds/" + namn + "/sidan", "w")
    s.write(str(sida))
    s.close()

    if end:
        pygame.quit()
        quit()
    else:
        main()


def main():
    sida = 0
    try:
        hu = open(".worlds/" + namn + "/sidan", "r")
        sida = int(hu.read())
        hu.close()
    except FileNotFoundError:
        "sidan finns inte"
    generator(sida)

    x, y = round(vidd / 2), 0

    # om du ändrar bakgrund, ändra obak till the same
    bakgrund = (70, 70, 255)
    obak = (70, 70, 255)

    hopp = False

    hoppnum = 0

    hall = "h"

    blittat = False

    bakgrundsbild = "yeah"

    kx, ky = 0, 0

    rutanmanpekarmot = 3

    hallerinum = 1

    halleri = "sand"

    hugg = False
    huggnum = 0

    ut = False
    utnum = 0

    # nummer av alla block man har # dia!
    sanum, jonum, lonum, trnum, stnum, dinum, smnum, grnum, kanum, granitnum, konum, kinum, tenum, zonum, nummer = \
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

    # för att den inte ska säga att blockbild kan vara not defined
    blockbild = ""

    # -||-
    bx, by = 0, 0

    under = False

    try:
        blocklaes = open(".worlds/" + namn + "/block", "r")
        laes = blocklaes.read()
        blocklaes.close()
        laes = laes.strip()
        sanum = int(laes.split("/")[0])
        jonum = int(laes.split("/")[1])
        lonum = int(laes.split("/")[2])
        trnum = int(laes.split("/")[3])
        stnum = int(laes.split("/")[4])
        dinum = int(laes.split("/")[5])
        smnum = int(laes.split("/")[6])
        grnum = int(laes.split("/")[7])
        kanum = int(laes.split("/")[8])
        granitnum = int(laes.split("/")[9])
        konum = int(laes.split("/")[10])
        kinum = int(laes.split("/")[11])
        tenum = int(laes.split("/")[12])
        zonum = int(laes.split("/")[13])
        # dia!

    except FileNotFoundError:
        "finns inte"
    except IndexError:
        "en finns inte"
    except ValueError:
        "en finns inte"

    nattnum = 0
    natt = False

    r = "/0"

    try:
        ro = open(".worlds/" + namn + "/natt", "r")
        r = ro.read()
        ro.close()
        r = r.strip()
        if r.split("/")[0]:
            natt = False
        if r.split("/")[0] == "True":
            natt = True
    except FileNotFoundError:
        "finns inte"
    try:
        nattnum = int(r.split("/")[1])
    except IndexError:
        "finns inte"

    ko_pa_pappret = False

    kox, koy = round(vidd / 2), 0

    hunger = 10
    try:
        hu = open(".worlds/" + namn + "/hunger", "r")
        hunger = float(hu.read())
        hu.close()
    except FileNotFoundError:
        "hunger finns inte"

    fredlig = "False"
    try:
        hu2 = open(".inställningar/fredlig", "r")
        fredlig = hu2.read()
        hu2.close()
    except FileNotFoundError:
        "fredlig finns inte"

    # ############################################################################### här börjar loopen

    while True:
        keys = pygame.key.get_pressed()

        # varje frame plusas nattnum med 1 och om det är 4000 så blir det natt/dag beroende på
        # vad det är före, och nattnum blir 0 igen
        nattnum += 1
        if nattnum > 4000:
            if natt:
                natt = False
            elif not natt:
                natt = True
            nattnum = 0
            blittat = False
        # det blir en annan bakgrund p.g.a. var man är och om det är natt
        if natt:
            bakgrund = (0, 0, 0)
        elif not natt:
            bakgrund = obak
        if under:
            bakgrund = (0, 0, 0)

        # vilket block som man ska ha mer/mindre av när man hugger/sätter ut
        if halleri == "sand":
            nummer = sanum
            blockbild = pygame.transform.scale(sand, (20, 20))
        elif halleri == "jord":
            nummer = jonum
            blockbild = pygame.transform.scale(jord, (20, 20))
        elif halleri == "loev":
            nummer = lonum
            blockbild = pygame.transform.scale(loev, (20, 20))
        elif halleri == "trae":
            nummer = trnum
            blockbild = pygame.transform.scale(trae, (20, 20))
        elif halleri == "sten":
            nummer = stnum
            blockbild = pygame.transform.scale(sten, (20, 20))
        elif halleri == "diamant":
            nummer = dinum
            blockbild = pygame.transform.scale(diamant, (20, 20))
        elif halleri == "smaragd":
            nummer = smnum
            blockbild = pygame.transform.scale(smaragd, (20, 20))
        elif halleri == "graes":
            nummer = grnum
            blockbild = pygame.transform.scale(graes, (20, 20))
        elif halleri == "kaktus":
            nummer = kanum
            blockbild = pygame.transform.scale(kaktus, (20, 20))
        elif halleri == "granit":
            nummer = granitnum
            blockbild = pygame.transform.scale(granit, (20, 20))
        elif halleri == "koblock":
            nummer = konum
            blockbild = pygame.transform.scale(koblock, (20, 20))
        elif halleri == "kista":
            nummer = kinum
            blockbild = pygame.transform.scale(kista, (20, 20))
        elif halleri == "tegel":
            nummer = tenum
            blockbild = pygame.transform.scale(tegel, (20, 20))
        elif halleri == "zombieblock":
            nummer = zonum
            blockbild = pygame.transform.scale(zombieblock, (20, 20))
        # dia!

        yeah = 0

        # 'g' står för generator
        gx = 0
        gy = 0

        gameDisplay.fill(bakgrund)

        if under:
            uplus = "u"
        else:
            uplus = ""

        for event in pygame.event.get():
            if event.type == pygame.QUIT or keys[pygame.K_ESCAPE]:
                avsluta(sanum, jonum, lonum, trnum, stnum, dinum, smnum, grnum, kanum, granitnum, konum, kinum,  # dia!
                        tenum, zonum, natt, nattnum, hunger, sida=sida)

            if event.type == pygame.KEYDOWN:
                key = pygame.key.get_pressed()
                if key[pygame.K_n]:
                    blnummer = 0
                    kollnum = 0
                    # medan det man bytte till är 0 eller mindre, byt till nästa
                    while not blnummer > 0:
                        if hallerinum == 1:
                            halleri = "jord"
                            hallerinum = 2
                            blnummer = jonum
                        elif hallerinum == 2:
                            halleri = "sand"
                            hallerinum = 3
                            blnummer = sanum
                        elif hallerinum == 3:
                            halleri = "loev"
                            hallerinum = 4
                            blnummer = lonum
                        elif hallerinum == 4:
                            halleri = "trae"
                            hallerinum = 5
                            blnummer = trnum
                        elif hallerinum == 5:
                            halleri = "sten"
                            hallerinum = 6
                            blnummer = stnum
                        elif hallerinum == 6:
                            halleri = "diamant"
                            hallerinum = 7
                            blnummer = dinum
                        elif hallerinum == 7:
                            halleri = "smaragd"
                            hallerinum = 8
                            blnummer = smnum
                        elif hallerinum == 8:
                            halleri = "graes"
                            hallerinum = 9
                            blnummer = grnum
                        elif hallerinum == 9:
                            halleri = "kaktus"
                            hallerinum = 10
                            blnummer = kanum
                        elif hallerinum == 10:
                            halleri = "granit"
                            hallerinum = 11
                            blnummer = granitnum
                        elif hallerinum == 11:
                            halleri = "koblock"
                            hallerinum = 12
                            blnummer = konum
                        elif hallerinum == 12:
                            halleri = "kista"
                            hallerinum = 13
                            blnummer = kinum
                        elif hallerinum == 13:
                            halleri = "tegel"
                            hallerinum = 14
                            blnummer = tenum
                        elif hallerinum == 14:
                            halleri = "zombieblock"
                            hallerinum = 1
                            blnummer = zonum
                        # dia!
                        kollnum += 1
                        if kollnum > 15:
                            blnummer = 1

                # äta
                if key[pygame.K_a]:
                    if halleri == "graes" and nummer > 0:
                        grnum -= 1
                        hunger += 1.0
                    if halleri == "koblock" and nummer > 0:
                        konum -= 1
                        hunger += 1.5
                    if halleri == "kaktus" and nummer > 0:
                        kanum -= 1
                        hunger += 0.7
                    if halleri == "loev" and nummer > 0:
                        lonum -= 1
                        hunger += 0.5

                if key[pygame.K_l]:
                    if globals()["ruta" + str(rutanmanpekarmot)] == "kista":
                        try:
                            kistor = open(".worlds/" + namn + "/" + str(sida) + "kista" + str(rutanmanpekarmot), "r")
                            kisto = kistor.read()
                            kistor.close()
                            sanum += int(kisto.split("/")[0])
                            jonum += int(kisto.split("/")[1])
                            lonum += int(kisto.split("/")[2])
                            trnum += int(kisto.split("/")[3])
                            stnum += int(kisto.split("/")[4])
                            dinum += int(kisto.split("/")[5])
                            smnum += int(kisto.split("/")[6])
                            grnum += int(kisto.split("/")[7])
                            kanum += int(kisto.split("/")[8])
                            granitnum += int(kisto.split("/")[9])
                            konum += int(kisto.split("/")[10])
                            kinum += int(kisto.split("/")[11])
                            tenum += int(kisto.split("/")[12])
                            zonum += int(kisto.split("/")[13])
                            # dia!
                        except FileNotFoundError:
                            "kistan har inget i sig"
                        except IndexError:
                            "en finns inte"
                        kisto = open(".worlds/" + namn + "/" + str(sida) + "kista" + str(rutanmanpekarmot), "w")
                        kisto.write(
                            str(sanum) + "/" + str(jonum) + "/" + str(lonum) + "/" + str(trnum) + "/" + str(stnum) + "/"
                            + str(dinum) + "/" + str(smnum) + "/" + str(grnum) + "/" + str(kanum) + "/" +
                            str(granitnum) + "/" + str(konum) + "/" + str(kinum) + "/" + str(tenum) + "/" + str(zonum))
                        # dia!
                        kisto.close()
                        time.sleep(0.2)
                        (sanum, jonum, lonum, trnum, stnum, dinum, smnum, grnum, kanum, granitnum, konum, kinum, tenum,
                         zonum) = (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)  # dia!
                if key[pygame.K_t]:
                    if globals()["ruta" + str(rutanmanpekarmot)] == "kista":
                        try:
                            kistor = open(".worlds/" + namn + "/" + str(sida) + "kista" + str(rutanmanpekarmot), "r")
                            kisto = kistor.read()
                            kistor.close()
                            sanum += int(kisto.split("/")[0])
                            jonum += int(kisto.split("/")[1])
                            lonum += int(kisto.split("/")[2])
                            trnum += int(kisto.split("/")[3])
                            stnum += int(kisto.split("/")[4])
                            dinum += int(kisto.split("/")[5])
                            smnum += int(kisto.split("/")[6])
                            grnum += int(kisto.split("/")[7])
                            kanum += int(kisto.split("/")[8])
                            granitnum += int(kisto.split("/")[9])
                            konum += int(kisto.split("/")[10])
                            kinum += int(kisto.split("/")[11])
                            tenum += int(kisto.split("/")[12])
                            zonum += int(kisto.split("/")[13])
                            # dia!
                            kisto = open(".worlds/" + namn + "/" + str(sida) + "kista" + str(rutanmanpekarmot), "w")
                            kisto.write("0/0/0/0/0/0/0/0/0/0/0/0/0/0")
                            kisto.close()
                        except FileNotFoundError:
                            "kista har inget i sig"
                        except IndexError:
                            "en finns inte"

        # i förra maxcraft så kördes denna loopen varje frame, men nu kör den bara när en ruta uppdateras,
        # som när man hugger eller sätter ut
        # efter det så sparar den bilden som bakgrund.png och visar den hela tiden
        # det borde ju bli mycket snabbare av det
        while not blittat:
            if globals()["ruta" + str(yeah)] == "sand":
                gameDisplay.blit(sand, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "jord":
                gameDisplay.blit(jord, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "loev":
                gameDisplay.blit(loev, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "trae":
                gameDisplay.blit(trae, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "sten":
                gameDisplay.blit(sten, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "diamant":
                gameDisplay.blit(diamant, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "smaragd":
                gameDisplay.blit(smaragd, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "graes":
                gameDisplay.blit(graes, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "kaktus":
                gameDisplay.blit(kaktus, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "granit":
                gameDisplay.blit(granit, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "koblock":
                gameDisplay.blit(koblock, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "kista":
                gameDisplay.blit(kista, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "tegel":
                gameDisplay.blit(tegel, (gx, gy))
            elif globals()["ruta" + str(yeah)] == "zombieblock":
                gameDisplay.blit(zombieblock, (gx, gy))
            # dia!

            gx += 50

            if gx > 950:
                gx = 0
                gy += 50

            yeah += 1

            if yeah > 254:
                pygame.image.save(gameDisplay, ".images/bakgrund.png")
                blittat = True

                bakgrundsbild = pygame.image.load(".images/bakgrund.png")

        gameDisplay.blit(bakgrundsbild, (0, 0))

        # om det finns en ko på pappret
        if ko_pa_pappret:
            gameDisplay.blit(ko, (kox, koy))
            try:
                if gameDisplay.get_at((kox + 40, koy + 75)) == bakgrund:
                    koy += 5
                else:
                    koy -= 5
            except IndexError:
                "den är ute"
            ko_move = random.randint(-5, 5)
            kox += ko_move

        gameDisplay.blit(person, (x, y))
        if fredlig == "False":
            skriv("Hunger: " + str(round(hunger, 2)), 0, 0, 25, (100, 50, 50))
            if hunger < 0:
                doe_funktion()

        try:
            if keys[pygame.K_LEFT]:
                if gameDisplay.get_at((x - 3, y + 20)) == bakgrund:
                    x -= 3
                    hunger -= 0.0001
                hall = "v"
            if keys[pygame.K_RIGHT]:
                if gameDisplay.get_at((x + 53, y + 20)) == bakgrund:
                    x += 3
                    hunger -= 0.0001
                hall = "h"
            if keys[pygame.K_SPACE] and not hopp and not gameDisplay.get_at((x + 25, y + 50)) == bakgrund:
                hopp = True
                hunger -= 0.001
                hoppnum = 0
        except IndexError:
            "out"
            if keys[pygame.K_LEFT]:
                if x - 5 < 0:
                    x -= 3
                    hunger -= 0.0001
                hall = "v"
            if keys[pygame.K_RIGHT]:
                if x + 55 > 1000:
                    x += 3
                    hunger -= 0.0001
            if keys[pygame.K_SPACE]:
                if y - 3 < 0 and under:
                    hopp = True
                    hunger -= 0.001

        if keys[pygame.K_UP]:
            hall = "u"
        if keys[pygame.K_DOWN]:
            hall = "n"

        # 'k' står för kryss
        # här visas bilden på blocket man håller i
        if hall == "h":
            kx = x + 75
            ky = y + 25
            bx = x + 75
            by = y + 15
        elif hall == "v":
            kx = x - 25
            ky = y + 25
            bx = x - 25
            by = y + 15
        elif hall == "u":
            kx = x + 25
            ky = y - 25
            bx = x + 15
            by = y - 35
        elif hall == "n":
            kx = x + 25
            ky = y + 75
            bx = x + 15
            by = y + 75

        if nummer > 0:
            gameDisplay.blit(blockbild, (bx, by))

        gameDisplay.blit(kryss, (kx, ky))

        if hopp:
            try:
                if gameDisplay.get_at((x + 25, y - 1)) == bakgrund:
                    y -= 3
                else:
                    hopp = False
                hoppnum += 1
                if hoppnum > 30:
                    hopp = False
            except IndexError:
                if y - 3 < 0 and under:
                    y -= 5
                else:
                    hopp = False
                    if y < 0 and not under:
                        y += 5

        try:
            if gameDisplay.get_at((x + 25, y + 50)) == bakgrund and not hopp:
                y += 5
        except IndexError:
            "out"

        rutax = x / 50
        rutay = y / 50

        rutax = round(rutax)
        rutay = round(rutay)

        rutanmanstarpa = rutay * 20 + rutax

        if hall == "h":
            rutanmanpekarmot = rutanmanstarpa + 1
        if hall == "v":
            rutanmanpekarmot = rutanmanstarpa - 1
        if hall == "u":
            rutanmanpekarmot = rutanmanstarpa - 20
        if hall == "n":
            rutanmanpekarmot = rutanmanstarpa + 20

        rutanmanpekarmot = str(rutanmanpekarmot).replace(".0", "")

        # hugga block
        if not kx > 1000 and not kx < 0 and 600 > ky > 0:
            if keys[pygame.K_x] and not hugg and not globals()["ruta" + str(rutanmanpekarmot)] == "air":
                if globals()["ruta" + str(rutanmanpekarmot)] == "sand":
                    sanum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "jord":
                    jonum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "loev":
                    lonum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "trae":
                    trnum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "sten":
                    stnum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "diamant":
                    dinum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "smaragd":
                    smnum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "loev":
                    lonum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "trae":
                    trnum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "graes":
                    grnum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "kaktus":
                    kanum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "granit":
                    granitnum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "koblock":
                    konum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "kista":
                    kinum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "tegel":
                    tenum += 1
                elif globals()["ruta" + str(rutanmanpekarmot)] == "zombieblock":
                    zonum += 1
                # dia!

                globals()["ruta" + str(rutanmanpekarmot)] = "air"

                dan = False
                op = open(".worlds/" + namn + "/sida" + str(sida) + uplus, "w")
                num2 = 0
                # spara hur pappret ser ut nu
                while not dan:
                    op.write(globals()["ruta" + str(num2)] + "/")
                    num2 += 1
                    if num2 > 255:
                        dan = True
                        op.close()

                blittat = False
                hugg = True
                huggnum = 0
            if keys[pygame.K_x] and not hugg:
                if kox < kx < kox + 100 and koy < ky < koy + 75 and ko_pa_pappret:
                    ko_pa_pappret = False
                    konum += 1

        # för att det inte ska bli jättehackigt, väntar en halv sekund (mindre) innan man kan hugga igen
        if hugg:
            huggnum += 1
            if huggnum > 10:
                hugg = False

        # sätta ut block
        if keys[pygame.K_v] and not ut and 0 < kx < 1000 and 0 < ky < 600:
            if globals()["ruta" + str(rutanmanpekarmot)] == "air" or globals()["ruta" + str(rutanmanpekarmot)] == "":
                if nummer > 0:
                    globals()["ruta" + str(rutanmanpekarmot)] = halleri

                    # blocket man håller i minskar med ett när man sätter ut det
                    if halleri == "sand":
                        sanum -= 1
                    elif halleri == "jord":
                        jonum -= 1
                    elif halleri == "loev":
                        lonum -= 1
                    elif halleri == "trae":
                        trnum -= 1
                    elif halleri == "sten":
                        stnum -= 1
                    elif halleri == "diamant":
                        dinum -= 1
                    elif halleri == "smaragd":
                        smnum -= 1
                    elif halleri == "loev":
                        lonum -= 1
                    elif halleri == "trae":
                        trnum -= 1
                    elif halleri == "graes":
                        grnum -= 1
                    elif halleri == "kaktus":
                        kanum -= 1
                    elif halleri == "granit":
                        granitnum -= 1
                    elif halleri == "koblock":
                        konum -= 1
                    elif halleri == "kista":
                        kinum -= 1
                    elif halleri == "tegel":
                        tenum -= 1
                    elif halleri == "zombieblock":
                        zonum -= 1
                    # dia!

                    dan = False
                    op = open(".worlds/" + namn + "/sida" + str(sida) + uplus, "w")
                    num2 = 0
                    # spara hur pappret ser ut nu
                    while not dan:
                        op.write(globals()["ruta" + str(num2)] + "/")
                        num2 += 1
                        if num2 > 255:
                            dan = True
                            op.close()

                    blittat = False

                    ut = True
                    utnum = 0

        # för att det inte ska bli jättehackigt

        if ut:
            utnum += 1
            if utnum > 10:
                ut = False

        # den checkar färg under sig, men med try, så om den är längst ner far gubben inga
        # ut för det är ju inte bakgrund längre ner
        if y + 53 > 600:
            y += 3

        # dö om man far ur världen

        if y > 600 and under:
            doe_funktion()

        # generera nytt papper om gubben går ut
        if x > 1000:
            if under:
                u = "u"
            else:
                u = ""
            generator(sida + 1, u)
            blittat = False
            x = 1
            sida += 1
            kokanske = random.randint(1, 5)
            if kokanske == 1 and not under:
                ko_pa_pappret = True
                koy = 0
            else:
                ko_pa_pappret = False
        elif x + 50 < 0:
            if under:
                u = "u"
            else:
                u = ""
            generator(sida - 1, u)
            blittat = False
            x = 950
            sida -= 1
            kokanske = random.randint(1, 5)
            if kokanske == 1 and not under:
                ko_pa_pappret = True
                koy = 0
            else:
                ko_pa_pappret = False

        if y > 600:
            under = True
            generator(sida, "u")
            blittat = False
            y = 1
        elif y < 0 and under:
            under = False
            generator(sida, "")
            blittat = False
            y = 500

        skriv(str(nummer), round(vidd / 2), 575, 25)

        if stnum > 1000:
            skriv("Grattis, tusen sten! ", 50, 300)
            time.sleep(1)
        if dinum > 20 or smnum > 20:
            skriv("Du är rik! ", 50, 300)

        pygame.display.update()


main()
