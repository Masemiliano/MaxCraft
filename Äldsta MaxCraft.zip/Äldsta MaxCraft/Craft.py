def all():
    import pygame
    import random

    pygame.init()

    vidd = 1000
    hoejd = 650

    mus = pygame.transform.scale((pygame.image.load(".images/.Mus.png")), (20, 20))
    mus_gron = pygame.transform.scale((pygame.image.load(".images/.Mus_grön.png")), (20, 20))
    jord = pygame.transform.scale((pygame.image.load(".images/gameDirtBlock.png")), (50, 50))
    trae = pygame.transform.scale((pygame.image.load(".images/gameWoodBlock.png")), (50, 50))
    sand = pygame.transform.scale((pygame.image.load(".images/gameSandBlock.png")), (50, 50))
    graes = pygame.transform.scale((pygame.image.load(".images/gameGrassBlock.png")), (50, 50))
    loev = pygame.transform.scale((pygame.image.load(".images/gameLeafBlock.png")), (50, 50))
    person = pygame.transform.scale((pygame.image.load(".images/Person.png")), (50, 50))
    kryss = pygame.transform.scale((pygame.image.load(".images/Kryss.png")), (5, 5))

    gameDisplay = pygame.display.set_mode((vidd, hoejd))

    pygame.mouse.set_visible(False)

    genererat = False
    genint = 0
    rutx = 0
    ruty = 0
    rutnum = 5


    def myround(x, base=50):
        return base * round(x/base)


    def skriv(text, x, y, storlek):
        font = pygame.font.SysFont(None, storlek)
        txt = font.render(text, True, (0, 0, 0))
        gameDisplay.blit(txt, (x, y))


    while not genererat:

        if ruty > 100:
            rutnum = random.randint(1, 5)

        else:
            kanske_loev = random.randint(1, 3)
            if kanske_loev == 1 or kanske_loev == 2:
                rutnum = 0
            else:
                rutnum = 5

        kolla = genint - 20

        try:
            if globals()["ruta" + str(kolla)].find("wood") != -1:
                rutnum = 2
        except:
            print("")

        try:
            if globals()["ruta" + str(genint - 1)].find("wood") != -1:
                rutnum = random.randint(1, 5)
        except:
            print("")

        if ruty > 400:
            slump = True
            while slump:
                rutnum = random.randint(1, 4)
                if rutnum != 2:
                    slump = False

        if rutnum == 1 and ruty < 400:
            slump = True
            while slump:
                rutnum = random.randint(1, 5)
                if rutnum != 1:
                    slump = False
        if rutnum == 3 and ruty < 400:
            slump = True
            while slump:
                rutnum = random.randint(1, 5)
                if rutnum != 3:
                    slump = False
        if rutnum == 4:
            if ruty > 450 or ruty < 400:
                slump = True
                while slump:
                    rutnum = random.randint(1, 5)
                    if rutnum != 4:
                        slump = False

        if rutnum == 0:
            rutaid = "leaf" + str(rutx) + ", " + str(ruty)
        elif rutnum == 1:
            rutaid = "dirt" + str(rutx) + ", " + str(ruty)
        elif rutnum == 2:
            rutaid = "wood" + str(rutx) + ", " + str(ruty)
        elif rutnum == 3:
            rutaid = "sand" + str(rutx) + ", " + str(ruty)
        elif rutnum == 4:
            rutaid = "grass" + str(rutx) + ", " + str(ruty)
        else:
            rutaid = "air" + str(rutx) + ", " + str(ruty)

        globals()["ruta" + str(genint)] = rutaid

        rutx += 50

        if rutx > 950:
            rutx = 0
            ruty += 50

        genint += 1

        if genint > 260:
            genererat = True

    spelexit = False

    clock = pygame.time.Clock()

    blittat = False

    bakgrund = (100, 100, 255)

    x = 500
    y = 0

    jump = False

    jumpcount = 0

    xhcheck = (0, 0, 0)
    xvcheck = (0, 0, 0)

    ner = ""

    hall = "h"

    kx = 0
    ky = 0

    rutanmanstarpa = ""

    ut = "wood"

    inte = False
    hugg = False

    while not spelexit:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

        gameDisplay.fill(bakgrund)

        yeah = 0

        while not blittat:
            ruta = globals()["ruta" + str(yeah)]

            if ruta.find("dirt") != -1:
                rutpos = ruta.replace("dirt", "")
                rutposx = int(rutpos.split(", ")[0])
                rutposy = int(rutpos.split(", ")[1])
                gameDisplay.blit(jord, (rutposx, rutposy))
            if ruta.find("wood") != -1:
                rutpos = ruta.replace("wood", "")
                rutposx = int(rutpos.split(", ")[0])
                rutposy = int(rutpos.split(", ")[1])
                gameDisplay.blit(trae, (rutposx, rutposy))
            if ruta.find("sand") != -1:
                rutpos = ruta.replace("sand", "")
                rutposx = int(rutpos.split(", ")[0])
                rutposy = int(rutpos.split(", ")[1])
                gameDisplay.blit(sand, (rutposx, rutposy))
            if ruta.find("grass") != -1:
                rutpos = ruta.replace("grass", "")
                rutposx = int(rutpos.split(", ")[0])
                rutposy = int(rutpos.split(", ")[1])
                gameDisplay.blit(graes, (rutposx, rutposy))
            if ruta.find("leaf") != -1:
                rutpos = ruta.replace("leaf", "")
                rutposx = int(rutpos.split(", ")[0])
                rutposy = int(rutpos.split(", ")[1])
                gameDisplay.blit(loev, (rutposx, rutposy))
            if ruta.find("air") != -1:
                rutpos = ruta.replace("air", "")
                rutposx = int(rutpos.split(", ")[0])
                rutposy = int(rutpos.split(", ")[1])

            yeah += 1
            if yeah > 260:
                yeah = 0
                blittat = True

        keys = pygame.key.get_pressed()

        if keys[pygame.K_ESCAPE]:
            pygame.quit()
            quit()

        gameDisplay.blit(person, (x, y))

        if hall == "h":
            kx = x + 75
            ky = y + 25
        if hall == "v":
            kx = x - 25
            ky = y + 25
        if hall == "u":
            kx = x + 25
            ky = y - 25
        if hall == "n":
            kx = x + 25
            ky = y + 75

        gameDisplay.blit(kryss, (kx, ky))

        position = pygame.mouse.get_pos()
        kolla = str(position).replace("(", "")
        kolla = kolla.replace(")", "")
        if int(kolla.split(",")[0]) > 600:
            gameDisplay.blit(mus, position)
        else:
            gameDisplay.blit(mus_gron, position)
        pygame.display.update()

        try:
            xhcheck = gameDisplay.get_at((x + 54, y + 10))
            xvcheck = gameDisplay.get_at((x - 4, y + 10))
        except:
            print("This is Max' craft game.")

        if keys[pygame.K_RIGHT] and not x + 60 > 1000:
            hall = "h"
            if xhcheck == bakgrund:
                x += 3
        if keys[pygame.K_LEFT] and not x - 3 < 0:
            hall = "v"
            if xvcheck == bakgrund:
                x -= 3
        if keys[pygame.K_UP]:
            hall = "u"

        if keys[pygame.K_DOWN]:
            hall = "n"

        if keys[pygame.K_SPACE]:
            try:
                if not gameDisplay.get_at((x + 25, y + 50)) == bakgrund:
                    jump = True
            except:
                print("Problem... ")

        if keys[pygame.K_n] and not inte:
            if ut == "wood":
                ut = "sand"
            elif ut == "sand":
                ut = "grass"
            elif ut == "grass":
                ut = "dirt"
            elif ut == "dirt":
                ut = "wood"
            inte = True
            nope = 0

        if inte:
            nope += 1
            if nope > 20:
                inte = False

        if keys[pygame.K_x] and not hugg:
            if hall == "h":
                globals()["ruta" + str(rutanmanstarpa + 1)] = ""
            if hall == "v":
                globals()["ruta" + str(rutanmanstarpa - 1)] = ""
            if hall == "u":
                globals()["ruta" + str(rutanmanstarpa - 20)] = ""
            if hall == "n":
                globals()["ruta" + str(rutanmanstarpa + 20)] = ""
            hugg = True
            hugnum = 0

        if hugg:
            hugnum += 1
            if hugnum > 15:
                hugg = False

        if keys[pygame.K_v]:
            rux = myround(x)
            ruy = myround(y)

            if hall == "h":
                globals()["ruta" + str(rutanmanstarpa + 1)] = ut + str(rux + 50) + ", " + str(ruy)
            if hall == "v":
                globals()["ruta" + str(rutanmanstarpa - 1)] = ut + str(rux - 50) + ", " + str(ruy)
            if hall == "u":
                globals()["ruta" + str(rutanmanstarpa - 20)] = ut + str(rux) + ", " + str(ruy - 50)
            if hall == "n":
                globals()["ruta" + str(rutanmanstarpa + 20)] = ut + str(rux) + ", " + str(ruy + 50)

        try:
            if not gameDisplay.get_at((x + 25, y - 10)) == bakgrund:
                jump = False
        except:
            print()

        if jump:
            y -= 10
            jumpcount += 1
            if jumpcount > 20:
                jumpcount = 0
                jump = False

        try:
            ner = gameDisplay.get_at((x + 25, y + 50))

        except:
            print("A little problem here... ")
            skriv("Tryck 'S' för att starta om.", vidd / 2, hoejd / 2, 75)


        if not jump and ner == bakgrund:
            y += 10

        rutax = x / 50
        rutay = y / 50

        rutax = round(rutax)
        rutay = round(rutay)

        rutanmanstarpa = rutay * 20 + rutax

        print(rutanmanstarpa)

        clock.tick(400)
        blittat = False


all()
